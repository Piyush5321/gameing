const board = document.getElementById("board");
const statusText = document.getElementById("status");
const startBtn = document.getElementById("startBtn");
const resetBtn = document.getElementById("reset");
const mineInput = document.getElementById("mineCount");

let mines = [];
let gameActive = false;

startBtn.addEventListener("click", startGame);
resetBtn.addEventListener("click", resetGame);

function startGame() {
  let mineCount = parseInt(mineInput.value);
  if (mineCount < 1 || mineCount > 24) {
    alert("Mines should be between 1 and 24!");
    return;
  }

  // Reset
  board.innerHTML = "";
  mines = [];
  gameActive = true;
  statusText.textContent = "Game started! Select a cell.";
  resetBtn.style.display = "inline-block";

  // Create grid
  for (let i = 0; i < 25; i++) {
    let cell = document.createElement("div");
    cell.classList.add("cell");
    cell.dataset.index = i;
    cell.addEventListener("click", handleClick);
    board.appendChild(cell);
  }

  // Random mines
  while (mines.length < mineCount) {
    let r = Math.floor(Math.random() * 25);
    if (!mines.includes(r)) {
      mines.push(r);
    }
  }
}

function handleClick(e) {
  if (!gameActive) return;

  let index = parseInt(e.target.dataset.index);

  if (mines.includes(index)) {
    e.target.classList.add("mine");
    e.target.textContent = "💣";
    statusText.textContent = "💥 Game Over! You hit a mine!";
    revealAll();
    gameActive = false;
  } else {
    e.target.classList.add("safe");
    e.target.textContent = "✔";
    statusText.textContent = "✅ Safe! Keep going...";
    e.target.removeEventListener("click", handleClick);
  }
}

function revealAll() {
  const cells = document.querySelectorAll(".cell");
  cells.forEach((cell, i) => {
    if (mines.includes(i)) {
      cell.classList.add("mine");
      cell.textContent = "💣";
    }
  });
}

function resetGame() {
  board.innerHTML = "";
  mines = [];
  gameActive = false;
  statusText.textContent = "Click Start to begin";
  resetBtn.style.display = "none";
}
