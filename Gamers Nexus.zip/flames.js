function playFlames() {
    let name1 = document.getElementById("name1").value.toLowerCase().replace(/\s/g, "");
    let name2 = document.getElementById("name2").value.toLowerCase().replace(/\s/g, "");
  
    if (name1 === "" || name2 === "") {
      document.getElementById("flames-result").innerText = "Result: Please enter both names!";
      return;
    }
  
    // Remove common letters
    for (let char of name1) {
      if (name2.includes(char)) {
        name1 = name1.replace(char, "");
        name2 = name2.replace(char, "");
      }
    }
  
    let count = name1.length + name2.length;
  
    let flames = ["Friends", "Love", "Affection", "Marriage", "Enemies", "Siblings"];
    let index = 0;
  
    while (flames.length > 1) {
      index = (index + count - 1) % flames.length;
      flames.splice(index, 1);
    }
  
    document.getElementById("flames-result").innerText = "Result: " + flames[0] + " 💖";
  }