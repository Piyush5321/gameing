const cells = document.querySelectorAll(".cell");
const statusText = document.getElementById("status");
const resetBtn = document.getElementById("reset");

let currentPlayer = "X";
let gameActive = true;
let gameState = ["", "", "", "", "", "", "", "", ""];

// Number pad mapping
const keyMap = {
  "7": 0, "8": 1, "9": 2,
  "4": 3, "5": 4, "6": 5,
  "1": 6, "2": 7, "3": 8
};

const winPatterns = [
  [0,1,2], [3,4,5], [6,7,8], // rows
  [0,3,6], [1,4,7], [2,5,8], // cols
  [0,4,8], [2,4,6]           // diagonals
];

// Keyboard input
document.addEventListener("keydown", (e) => {
  if (!gameActive) return;
  if (keyMap[e.key] !== undefined) {
    handleMove(keyMap[e.key]);
  }
});

// Mouse click input
cells.forEach(cell => {
  cell.addEventListener("click", () => {
    if (!gameActive) return;
    handleMove(cell.dataset.index);
  });
});

function handleMove(index) {
  index = parseInt(index);
  if (gameState[index] !== "" || !gameActive) return;

  gameState[index] = currentPlayer;
  cells[index].textContent = currentPlayer;
  cells[index].classList.add("taken");

  if (checkWin()) {
    highlightWin();
    statusText.textContent = `🎉 Player ${currentPlayer} Wins! 🎉`;
    gameActive = false;
    return;
  }

  if (!gameState.includes("")) {
    statusText.textContent = "🤝 It's a Draw!";
    gameActive = false;
    return;
  }

  currentPlayer = currentPlayer === "X" ? "O" : "X";
  statusText.textContent = `Player ${currentPlayer}'s Turn`;
}

function checkWin() {
  return winPatterns.some(pattern => {
    return pattern.every(index => gameState[index] === currentPlayer);
  });
}

function highlightWin() {
  winPatterns.forEach(pattern => {
    if (pattern.every(index => gameState[index] === currentPlayer)) {
      pattern.forEach(index => {
        cells[index].classList.add("win");
      });
    }
  });
}

resetBtn.addEventListener("click", resetGame);

function resetGame() {
  currentPlayer = "X";
  gameActive = true;
  gameState = ["", "", "", "", "", "", "", "", ""];
  cells.forEach(cell => {
    cell.textContent = "";
    cell.classList.remove("taken", "win");
  });
  statusText.textContent = `Player ${currentPlayer}'s Turn`;
}
