(() => {
  const words = ['javascript','neon','hangman','computer','bicycle','puzzle'];

  const wordEl = document.getElementById('word');
  const wrongLettersEl = document.getElementById('wrongLetters');
  const livesEl = document.getElementById('lives');
  const messageEl = document.getElementById('message');
  const keyboardEl = document.getElementById('keyboard');
  const newBtn = document.getElementById('newBtn');

  let secretWord = '';
  let revealed = [];
  let wrong = [];
  const maxLives = 6;

  function pickWord(){
    secretWord = words[Math.floor(Math.random()*words.length)];
    revealed = Array(secretWord.length).fill(false);
    wrong = [];
    updateUI();
    enableKeys();
    messageEl.textContent = '';
  }

  function updateUI(){
    wordEl.textContent = revealed.map((v,i)=>v?secretWord[i].toUpperCase():'_').join(' ');
    wrongLettersEl.textContent = wrong.join(', ');
    livesEl.textContent = maxLives - wrong.length;
  }

  function buildKeyboard(){
    keyboardEl.innerHTML = '';
    for(let i=65;i<=90;i++){
      const letter = String.fromCharCode(i);
      const btn = document.createElement('button');
      btn.className='key';
      btn.textContent=letter;
      btn.dataset.letter = letter.toLowerCase();
      btn.onclick = () => selectLetter(letter.toLowerCase());
      keyboardEl.appendChild(btn);
    }
  }

  function selectLetter(letter){
    const btn = [...keyboardEl.children].find(b => b.dataset.letter === letter);
    if(btn) btn.classList.add('used');
    if(revealed.every(v=>v) || wrong.length>=maxLives) return;

    if(secretWord.includes(letter)){
      secretWord.split('').forEach((ch,i)=>{ if(ch===letter) revealed[i]=true; });
      updateUI();
      if(revealed.every(v=>v)) messageEl.textContent='🎉 You Win!';
    } else {
      if(!wrong.includes(letter)){
        wrong.push(letter);
        updateUI();
        if(wrong.length>=maxLives){
          messageEl.textContent = `💀 You Lost! Word: ${secretWord.toUpperCase()}`;
          revealed = secretWord.split('').map(()=>true);
          updateUI();
        }
      }
    }
  }

  function enableKeys(){
    for(let b of keyboardEl.children){
      b.disabled=false;
      b.classList.remove('used');
    }
  }

  window.addEventListener('keydown', e=>{
    if(/^[a-zA-Z]$/.test(e.key)) selectLetter(e.key.toLowerCase());
    if(e.key==='Enter') pickWord();
  });

  newBtn.onclick = pickWord;

  buildKeyboard();
  pickWord();
})();